#ifndef _LINUX_MEMFD_H
#define _LINUX_MEMFD_H

/* flags for memfd_create(2) (unsigned int) */
#define MFD_CLOEXEC		0x0001U
#define MFD_ALLOW_SEALING	0x0002U

#endif /* _LINUX_MEMFD_H */
